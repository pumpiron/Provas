import FormPessoa from "../components/form_pessoa";
import Link from 'next/link'

/*export default function Incluir() {
  return (
    
    <div className="p-4 bg-black min-h-screen text-white">
        <Link className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition" href="/">Início</Link>
        <main className="text-center text-3xl font-bold my-6">
          Nova música
        </main>
        <FormPessoa />
    </div>
  );
}
*/
export default function Incluir() {
  return (
    <div className="bg-black min-h-screen flex flex-col items-right text-white p-4">

      <Link 
        className="bg-red-600 text-white px-5 py-2 rounded-lg hover:bg-red-700 transition self-start mb-6" 
        href="/"
      >
        Início
      </Link>

      <main className="text-3xl font-bold mb-6 text-center">
        Nova música
      </main>

      <FormPessoa />
    </div>
  );
}