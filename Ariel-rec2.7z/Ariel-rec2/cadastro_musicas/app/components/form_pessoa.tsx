export default function FormPessoa() {
  return (
    <div className="flex justify-center">
      <form className="flex flex-col w-80 bg-gray-900 p-6 rounded-lg shadow-lg">
        
        <label className="mb-1">Música: </label>
        <input className="border rounded px-2 py-1 mb-3 text-white" type="text" name="musica" />
        
        <label className="mb-1">Artista: </label>
        <input className="border rounded px-2 py-1 mb-3 text-white" type="text" name="artista" />
        
        <label className="mb-1">Ano: </label>
        <input className="border rounded px-2 py-1 mb-4 text-white" type="text" name="ano" />
        
        <button 
          className="bg-white text-black font-bold px-4 py-2 rounded hover:bg-gray-200 transition" 
          type="submit">
          Incluir!
        </button>
      </form>
    </div>
  );
}