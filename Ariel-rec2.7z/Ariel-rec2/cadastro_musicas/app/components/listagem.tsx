export default function Listagem() {
  return (
    <div className="m-8 text-center">
      <h1 className="text-2xl border-b-4 border-white pb-2 mb-6">
        Top 10 maiores músicas da história
      </h1>

      <table className="table-auto border border-white m-auto rounded-lg shadow-lg">
        <thead>
          <tr className="bg-gray-800 text-white">
            <th className="text-left px-4 py-2 w-1/2">Música</th>
            <th className="text-left px-4 py-2 w-1/3">Artista</th>
            <th className="text-left px-4 py-2 w-1/6">Ano</th>
          </tr>
        </thead>
        <tbody>
          <tr className="hover:bg-white hover:text-black transition">
            <td className="text-left px-4 py-2">The Sliding Mr. Bones (Next Stop, Pottersville)</td>
            <td className="text-left px-4 py-2">Malcolm Lockyer</td>
            <td className="text-left px-4 py-2">1961</td>
          </tr>
          <tr className="hover:bg-white hover:text-black transition">
            <td className="text-left px-4 py-2">Witchy Woman</td>
            <td className="text-left px-4 py-2">The Eagles</td>
            <td className="text-left px-4 py-2">1972</td>
          </tr>
          <tr className="hover:bg-white hover:text-black transition">
            <td className="text-left px-4 py-2">Shining Star</td>
            <td className="text-left px-4 py-2">Earth, Wind, and Fire</td>
            <td className="text-left px-4 py-2">1975</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

